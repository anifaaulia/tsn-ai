url = """
https://tsn.thai-tech.ac.th/history/,
https://tsn.thai-tech.ac.th/founders/,
https://tsn.thai-tech.ac.th/philosophy-vision/,
https://tsn.thai-tech.ac.th/register-landing/programs/bita/,
https://tsn.thai-tech.ac.th/register-landing/programs/imat/,
https://tsn.thai-tech.ac.th/register-landing/programs/dbi/,
https://tsn.thai-tech.ac.th/programs/logistics/,
https://tsn.thai-tech.ac.th/programs/tourism-industry-ihat-program/,
https://tsn.thai-tech.ac.th/programs/retail-business/,
https://tsn.thai-tech.ac.th/programs/ies/,
https://tsn.thai-tech.ac.th/news-showcases/,
https://tsn.thai-tech.ac.th/contact/,
"""
